import { TrendingUp, TrendingDown, AlertTriangle, Calendar, Users, Target, Brain, Activity } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, AreaChart, Area, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Prédiction de charge de travail (tickets)
const workloadPredictionData = [
  { semaine: 'S-4', reel: 45, predit: null },
  { semaine: 'S-3', reel: 52, predit: null },
  { semaine: 'S-2', reel: 48, predit: null },
  { semaine: 'S-1', reel: 55, predit: null },
  { semaine: 'S0', reel: 60, predit: 60 },
  { semaine: 'S+1', reel: null, predit: 65 },
  { semaine: 'S+2', reel: null, predit: 68 },
  { semaine: 'S+3', reel: null, predit: 62 },
  { semaine: 'S+4', reel: null, predit: 58 },
];

// Prédiction des demandes de congés
const leavePredictionData = [
  { mois: 'Avr', reel: 45, predit: null },
  { mois: 'Mai', reel: 62, predit: null },
  { mois: 'Juin', reel: 78, predit: null },
  { mois: 'Juil', reel: 95, predit: 95 },
  { mois: 'Août', reel: null, predit: 125 },
  { mois: 'Sep', reel: null, predit: 85 },
  { mois: 'Oct', reel: null, predit: 42 },
];

// Prédiction du turnover
const turnoverPredictionData = [
  { trimestre: 'T1', departs: 8, predictedDeparts: null },
  { trimestre: 'T2', departs: 12, predictedDeparts: null },
  { trimestre: 'T3', departs: 10, predictedDeparts: null },
  { trimestre: 'T4', departs: null, predictedDeparts: 14 },
  { trimestre: 'T1+1', departs: null, predictedDeparts: 11 },
];

// Analyse de corrélation (absences vs productivité)
const correlationData = [
  { absences: 2, productivite: 95 },
  { absences: 5, productivite: 88 },
  { absences: 8, productivite: 82 },
  { absences: 12, productivite: 75 },
  { absences: 15, productivite: 68 },
  { absences: 18, productivite: 62 },
  { absences: 22, productivite: 55 },
];

// Analyse des risques prédictifs
const riskAnalysis = [
  {
    id: 1,
    type: 'Charge de travail',
    niveau: 'ÉLEVÉ',
    probabilite: '85%',
    impact: 'Haut',
    prevision: 'Surcharge tickets S+1 et S+2',
    action: 'Planifier ressources supplémentaires',
    color: 'red'
  },
  {
    id: 2,
    type: 'Congés été',
    niveau: 'MOYEN',
    probabilite: '92%',
    impact: 'Moyen',
    prevision: 'Pic de demandes en Août (+60%)',
    action: 'Anticiper les validations',
    color: 'orange'
  },
  {
    id: 3,
    type: 'Turnover',
    niveau: 'FAIBLE',
    probabilite: '68%',
    impact: 'Moyen',
    prevision: 'Légère hausse T4 (+2 départs)',
    action: 'Renforcer fidélisation',
    color: 'green'
  },
  {
    id: 4,
    type: 'Absentéisme',
    niveau: 'MOYEN',
    probabilite: '75%',
    impact: 'Moyen',
    prevision: 'Tendance haussière détectée',
    action: 'Analyser causes racines',
    color: 'orange'
  },
];

// Métriques prédictives
const predictiveMetrics = [
  {
    label: 'Charge Prévue (7j)',
    value: '+18%',
    trend: 'up',
    confidence: '87%',
    description: 'vs semaine courante',
    color: 'red'
  },
  {
    label: 'Demandes Congés (30j)',
    value: '+45%',
    trend: 'up',
    confidence: '92%',
    description: 'Pic estival prévu',
    color: 'orange'
  },
  {
    label: 'Taux Rétention',
    value: '94.8%',
    trend: 'stable',
    confidence: '78%',
    description: 'Stable prochain trimestre',
    color: 'green'
  },
  {
    label: 'Productivité Prévue',
    value: '-3%',
    trend: 'down',
    confidence: '81%',
    description: 'Impact congés estivaux',
    color: 'orange'
  },
];

export function PredictiveAnalytics() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Analyse Prédictive</h2>
          <p className="text-gray-600 mt-1">Anticipation de la charge de travail et des tendances RH</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 border border-purple-200 rounded-lg">
          <Brain className="text-purple-600" size={20} />
          <span className="text-sm font-medium text-purple-700">Modèle IA actif</span>
        </div>
      </div>

      {/* Predictive Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {predictiveMetrics.map((metric) => (
          <div key={metric.label} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm text-gray-600">{metric.label}</div>
              {metric.trend === 'up' && <TrendingUp className={`text-${metric.color}-600`} size={20} />}
              {metric.trend === 'down' && <TrendingDown className={`text-${metric.color}-600`} size={20} />}
              {metric.trend === 'stable' && <Activity className={`text-${metric.color}-600`} size={20} />}
            </div>
            <div className="text-3xl font-bold text-gray-800 mb-1">{metric.value}</div>
            <div className="text-xs text-gray-500 mb-2">{metric.description}</div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-${metric.color}-600`}
                  style={{ width: metric.confidence }}
                ></div>
              </div>
              <span className="text-xs text-gray-600">{metric.confidence}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Workload Prediction */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Prédiction Charge de Travail</h3>
              <p className="text-sm text-gray-500 mt-1">Tickets support prévus (4 prochaines semaines)</p>
            </div>
            <Target className="text-blue-600" size={24} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={workloadPredictionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="semaine" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="reel"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Réel"
                dot={{ r: 5 }}
              />
              <Line
                type="monotone"
                dataKey="predit"
                stroke="#10b981"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Prédit"
                dot={{ r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Leave Prediction */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Prédiction Demandes de Congés</h3>
              <p className="text-sm text-gray-500 mt-1">Anticipation des périodes de forte demande</p>
            </div>
            <Calendar className="text-orange-600" size={24} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={leavePredictionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mois" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area
                type="monotone"
                dataKey="reel"
                stroke="#3b82f6"
                fill="#93c5fd"
                name="Réel"
              />
              <Area
                type="monotone"
                dataKey="predit"
                stroke="#f59e0b"
                fill="#fcd34d"
                fillOpacity={0.6}
                strokeDasharray="5 5"
                name="Prédit"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Turnover Prediction */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Prédiction Turnover</h3>
              <p className="text-sm text-gray-500 mt-1">Anticipation des départs par trimestre</p>
            </div>
            <Users className="text-purple-600" size={24} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={turnoverPredictionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="trimestre" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="departs" fill="#3b82f6" name="Départs Réels" />
              <Bar dataKey="predictedDeparts" fill="#8b5cf6" name="Départs Prévus" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Correlation Analysis */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Analyse de Corrélation</h3>
              <p className="text-sm text-gray-500 mt-1">Impact des absences sur la productivité</p>
            </div>
            <Activity className="text-green-600" size={24} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                type="number"
                dataKey="absences"
                name="Absences (%)"
                unit="%"
              />
              <YAxis
                type="number"
                dataKey="productivite"
                name="Productivité"
                unit="%"
              />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter
                name="Corrélation"
                data={correlationData}
                fill="#10b981"
                line={{ stroke: '#10b981', strokeWidth: 2 }}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Risk Analysis Table */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="text-orange-600" size={24} />
          <h3 className="text-lg font-semibold text-gray-800">Analyse des Risques Prédictifs</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Type de Risque</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Niveau</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Probabilité</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Impact</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Prévision</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Action Recommandée</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {riskAnalysis.map((risk) => (
                <tr key={risk.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{risk.type}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      risk.color === 'red' ? 'bg-red-100 text-red-700' :
                      risk.color === 'orange' ? 'bg-orange-100 text-orange-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {risk.niveau}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">{risk.probabilite}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{risk.impact}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{risk.prevision}</td>
                  <td className="px-6 py-4 text-sm text-blue-600">{risk.action}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Model Info */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-lg bg-purple-600 flex items-center justify-center flex-shrink-0">
            <Brain className="text-white" size={24} />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Modèle d'Intelligence Artificielle</h3>
            <p className="text-sm text-gray-700 mb-3">
              Les prédictions sont générées par un modèle d'apprentissage automatique entraîné sur 24 mois de données historiques.
              Le modèle utilise des algorithmes de séries temporelles (ARIMA, Prophet) et de machine learning (Random Forest, XGBoost)
              pour anticiper les tendances et identifier les risques.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-gray-700">Précision moyenne: <strong>86.3%</strong></span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-gray-700">Dernière mise à jour: <strong>23 mars 2026</strong></span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span className="text-gray-700">Prochain entraînement: <strong>1 avril 2026</strong></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
