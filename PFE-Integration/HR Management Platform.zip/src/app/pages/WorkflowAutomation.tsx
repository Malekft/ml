import { Zap, Mail, Bell, Clock, CheckCircle, Play, Pause } from 'lucide-react';

interface Workflow {
  id: number;
  name: string;
  description: string;
  trigger: string;
  actions: string[];
  status: 'active' | 'paused';
  executions: number;
  lastRun: string;
}

const mockWorkflows: Workflow[] = [
  {
    id: 1,
    name: 'Notification congés approuvés',
    description: 'Envoie automatiquement un email et une notification quand un congé est approuvé',
    trigger: 'Congé approuvé',
    actions: ['Email employé', 'Notification in-app', 'Mise à jour calendrier'],
    status: 'active',
    executions: 127,
    lastRun: '2026-03-23 11:30',
  },
  {
    id: 2,
    name: 'Rappel SLA Tickets',
    description: 'Envoie un rappel après 48h si un ticket n\'a pas été traité',
    trigger: 'Ticket ouvert depuis 48h',
    actions: ['Email manager', 'Notification urgente', 'Escalade priorité'],
    status: 'active',
    executions: 43,
    lastRun: '2026-03-22 18:00',
  },
  {
    id: 3,
    name: 'Publication LinkedIn automatique',
    description: 'Publie automatiquement les annonces RH sur LinkedIn',
    trigger: 'Nouvelle annonce créée',
    actions: ['Publication LinkedIn', 'Notification équipe RH'],
    status: 'active',
    executions: 8,
    lastRun: '2026-03-20 09:15',
  },
  {
    id: 4,
    name: 'Onboarding nouvel employé',
    description: 'Workflow complet pour l\'intégration d\'un nouvel employé',
    trigger: 'Employé créé',
    actions: ['Email bienvenue', 'Création compte IT', 'Attribution matériel', 'Planning formation'],
    status: 'paused',
    executions: 15,
    lastRun: '2026-03-15 10:00',
  },
  {
    id: 5,
    name: 'Validation demandes urgentes',
    description: 'Notifie immédiatement le manager pour toute demande urgente',
    trigger: 'Demande priorité URGENT',
    actions: ['SMS manager', 'Email', 'Notification push'],
    status: 'active',
    executions: 22,
    lastRun: '2026-03-23 09:45',
  },
];

export function WorkflowAutomation() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Automatisation & Workflows</h2>
          <p className="text-gray-600 mt-1">Gérez vos automatisations n8n et notifications</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Zap size={20} />
          Créer un workflow
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-blue-600">{mockWorkflows.length}</div>
            <Zap className="text-blue-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Workflows totaux</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-green-600">
              {mockWorkflows.filter(w => w.status === 'active').length}
            </div>
            <Play className="text-green-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Actifs</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-orange-600">
              {mockWorkflows.filter(w => w.status === 'paused').length}
            </div>
            <Pause className="text-orange-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">En pause</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-purple-600">
              {mockWorkflows.reduce((sum, w) => sum + w.executions, 0)}
            </div>
            <CheckCircle className="text-purple-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Exécutions totales</div>
        </div>
      </div>

      {/* Workflow Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockWorkflows.map((workflow) => (
          <div
            key={workflow.id}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  workflow.status === 'active' ? 'bg-green-100' : 'bg-gray-100'
                }`}>
                  <Zap className={workflow.status === 'active' ? 'text-green-600' : 'text-gray-600'} size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-1">{workflow.name}</h3>
                  <p className="text-sm text-gray-600">{workflow.description}</p>
                </div>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  workflow.status === 'active'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-gray-100 text-gray-700'
                }`}
              >
                {workflow.status === 'active' ? 'Actif' : 'En pause'}
              </span>
            </div>

            {/* Trigger */}
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-blue-800">
                <Zap size={16} />
                <span className="font-medium">Déclencheur:</span>
                <span>{workflow.trigger}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="mb-4">
              <div className="text-sm font-medium text-gray-700 mb-2">Actions automatiques:</div>
              <div className="space-y-2">
                {workflow.actions.map((action, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs font-medium">
                      {index + 1}
                    </div>
                    {action.includes('Email') && <Mail size={16} className="text-blue-600" />}
                    {action.includes('Notification') && <Bell size={16} className="text-orange-600" />}
                    {action.includes('Calendrier') && <Clock size={16} className="text-green-600" />}
                    <span>{action}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
              <span>{workflow.executions} exécutions</span>
              <span>Dernière: {workflow.lastRun}</span>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                Modifier
              </button>
              <button
                className={`px-4 py-2 rounded-lg transition-colors text-sm ${
                  workflow.status === 'active'
                    ? 'bg-orange-100 text-orange-700 hover:bg-orange-200'
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {workflow.status === 'active' ? 'Mettre en pause' : 'Activer'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Notification Settings */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Paramètres de Notifications</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">Notifications Email</h4>
            <label className="flex items-center gap-3">
              <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Congés approuvés/refusés</span>
            </label>
            <label className="flex items-center gap-3">
              <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Nouveaux tickets assignés</span>
            </label>
            <label className="flex items-center gap-3">
              <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Rappels SLA</span>
            </label>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">Notifications In-App</h4>
            <label className="flex items-center gap-3">
              <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Mises à jour de tickets</span>
            </label>
            <label className="flex items-center gap-3">
              <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Nouvelles annonces</span>
            </label>
            <label className="flex items-center gap-3">
              <input type="checkbox" className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-700">Rappels quotidiens</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
