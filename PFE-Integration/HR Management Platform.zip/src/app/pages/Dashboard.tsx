import { Users, Calendar, Ticket, TrendingUp, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const statsCards = [
  { icon: Users, label: 'Employés Actifs', value: '248', change: '+12%', color: 'blue' },
  { icon: Calendar, label: 'Demandes de Congés', value: '32', change: '+5%', color: 'green' },
  { icon: Ticket, label: 'Tickets Ouverts', value: '18', change: '-8%', color: 'orange' },
  { icon: TrendingUp, label: 'Taux de Satisfaction', value: '94%', change: '+3%', color: 'purple' },
];

const absenteeismData = [
  { name: 'Jan', absences: 12 },
  { name: 'Fév', absences: 15 },
  { name: 'Mar', absences: 8 },
  { name: 'Avr', absences: 18 },
  { name: 'Mai', absences: 10 },
  { name: 'Juin', absences: 14 },
];

const projectsData = [
  { month: 'Jan', projets: 12 },
  { month: 'Fév', projets: 15 },
  { month: 'Mar', projets: 18 },
  { month: 'Avr', projets: 14 },
  { month: 'Mai', projets: 20 },
  { month: 'Juin', projets: 22 },
];

const ticketStatusData = [
  { name: 'Résolu', value: 45, color: '#10b981' },
  { name: 'En cours', value: 18, color: '#f59e0b' },
  { name: 'Urgent', value: 8, color: '#ef4444' },
  { name: 'En attente', value: 12, color: '#6b7280' },
];

const recentActivities = [
  { id: 1, user: 'Marie Dubois', action: 'a soumis une demande de congé', time: 'Il y a 5 min', type: 'success' },
  { id: 2, user: 'Jean Martin', action: 'a créé un ticket (Urgent)', time: 'Il y a 15 min', type: 'urgent' },
  { id: 3, user: 'Sophie Bernard', action: 'a validé 3 demandes de congés', time: 'Il y a 1h', type: 'info' },
  { id: 4, user: 'Luc Petit', action: 'a mis à jour son profil', time: 'Il y a 2h', type: 'info' },
];

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg bg-${stat.color}-100 flex items-center justify-center`}>
                  <Icon className={`text-${stat.color}-600`} size={24} />
                </div>
                <span className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Absenteeism Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Absentéisme (6 derniers mois)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={absenteeismData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="absences" stroke="#3b82f6" fill="#93c5fd" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Projects Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Projets Clients Livrés</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={projectsData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="projets" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ticket Status */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Statut des Tickets</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={ticketStatusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => entry.name}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {ticketStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Activities */}
        <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Activités Récentes</h3>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 pb-4 border-b border-gray-100 last:border-0">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'urgent' ? 'bg-red-500' : 'bg-blue-500'
                }`}></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-800">
                    <span className="font-medium">{activity.user}</span> {activity.action}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SLA Monitoring */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Suivi SLA - Temps de Réponse Moyen</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
            <CheckCircle className="text-green-600" size={24} />
            <div>
              <div className="text-2xl font-bold text-green-600">2.3h</div>
              <div className="text-sm text-gray-600">Tickets Normaux</div>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-orange-50 rounded-lg">
            <Clock className="text-orange-600" size={24} />
            <div>
              <div className="text-2xl font-bold text-orange-600">1.5h</div>
              <div className="text-sm text-gray-600">Priorité Moyenne</div>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-red-50 rounded-lg">
            <AlertCircle className="text-red-600" size={24} />
            <div>
              <div className="text-2xl font-bold text-red-600">0.8h</div>
              <div className="text-sm text-gray-600">Tickets Urgents</div>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
            <TrendingUp className="text-blue-600" size={24} />
            <div>
              <div className="text-2xl font-bold text-blue-600">92%</div>
              <div className="text-sm text-gray-600">Taux SLA Respecté</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
