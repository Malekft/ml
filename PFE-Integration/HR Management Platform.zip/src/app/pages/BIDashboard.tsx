import { Download, Filter, TrendingUp, TrendingDown } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const employeeTurnoverData = [
  { month: 'Jan', embauches: 8, departs: 3 },
  { month: 'Fév', embauches: 5, departs: 4 },
  { month: 'Mar', embauches: 12, departs: 2 },
  { month: 'Avr', embauches: 7, departs: 5 },
  { month: 'Mai', embauches: 10, departs: 3 },
  { month: 'Juin', embauches: 6, departs: 6 },
];

const projectTypeDistribution = [
  { name: 'Illustration', value: 58, color: '#3b82f6' },
  { name: 'Design 3D', value: 45, color: '#10b981' },
  { name: 'Motion Design', value: 32, color: '#f59e0b' },
  { name: 'Branding', value: 28, color: '#8b5cf6' },
  { name: 'Retouche Photo', value: 22, color: '#ef4444' },
];

const leavesTrendData = [
  { month: 'Jan', conges: 45, rtt: 12, maladie: 8 },
  { month: 'Fév', conges: 38, rtt: 15, maladie: 11 },
  { month: 'Mar', conges: 52, rtt: 18, maladie: 6 },
  { month: 'Avr', conges: 65, rtt: 20, maladie: 9 },
  { month: 'Mai', conges: 78, rtt: 22, maladie: 7 },
  { month: 'Juin', conges: 92, rtt: 25, maladie: 10 },
];

const ticketResolutionData = [
  { week: 'S1', resolu: 35, enCours: 12 },
  { week: 'S2', resolu: 42, enCours: 8 },
  { week: 'S3', resolu: 38, enCours: 15 },
  { week: 'S4', resolu: 45, enCours: 10 },
  { week: 'S5', resolu: 50, enCours: 6 },
  { week: 'S6', resolu: 48, enCours: 9 },
];

export function BIDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Tableaux de Bord BI</h2>
          <p className="text-gray-600 mt-1">Analyses avancées et KPI stratégiques</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
            <Filter size={20} />
            Filtres
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Download size={20} />
            Exporter PDF
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Effectif Total</div>
            <TrendingUp className="text-green-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">248</div>
          <div className="flex items-center gap-1 text-sm text-green-600">
            <TrendingUp size={16} />
            <span>+8% vs mois dernier</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Taux de Rétention</div>
            <TrendingUp className="text-green-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">94.2%</div>
          <div className="flex items-center gap-1 text-sm text-green-600">
            <TrendingUp size={16} />
            <span>+2.1% vs année dernière</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Taux d'Absentéisme</div>
            <TrendingDown className="text-red-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">3.8%</div>
          <div className="flex items-center gap-1 text-sm text-red-600">
            <TrendingUp size={16} />
            <span>+0.5% vs mois dernier</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Coût Moyen/Employé</div>
            <TrendingUp className="text-orange-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">4,250€</div>
          <div className="flex items-center gap-1 text-sm text-orange-600">
            <TrendingUp size={16} />
            <span>+3.2% vs trimestre dernier</span>
          </div>
        </div>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Employee Turnover */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Rotation du Personnel (6 mois)</h3>
            <button className="text-sm text-blue-600 hover:underline">Voir détails</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={employeeTurnoverData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="embauches" fill="#10b981" name="Embauches" />
              <Bar dataKey="departs" fill="#ef4444" name="Départs" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Project Type Distribution */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Répartition par Type de Projet</h3>
            <button className="text-sm text-blue-600 hover:underline">Voir détails</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={projectTypeDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.name} (${entry.value})`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {projectTypeDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leaves Trend */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Tendances Congés & Absences</h3>
            <button className="text-sm text-blue-600 hover:underline">Exporter Excel</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={leavesTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="conges" stackId="1" stroke="#3b82f6" fill="#93c5fd" name="Congés" />
              <Area type="monotone" dataKey="rtt" stackId="1" stroke="#10b981" fill="#86efac" name="RTT" />
              <Area type="monotone" dataKey="maladie" stackId="1" stroke="#ef4444" fill="#fca5a5" name="Maladie" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Ticket Resolution */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Performance Support (6 semaines)</h3>
            <button className="text-sm text-blue-600 hover:underline">Voir détails</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={ticketResolutionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="resolu" stroke="#10b981" strokeWidth={2} name="Tickets Résolus" />
              <Line type="monotone" dataKey="enCours" stroke="#f59e0b" strokeWidth={2} name="En Cours" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Détails par Type de Projet</h3>
          <button className="flex items-center gap-2 px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm">
            <Download size={16} />
            Exporter
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Type de Projet</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Projets (mois)</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Délai Moyen</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Taux Satisfaction</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Tendance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {projectTypeDistribution.map((project) => (
                <tr key={project.name} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{project.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{project.value}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{Math.floor(Math.random() * 5 + 3)} jours</td>
                  <td className="px-6 py-4 text-sm">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                      {Math.floor(Math.random() * 10 + 85)}%
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-1 text-green-600">
                      <TrendingUp size={16} />
                      <span>+{Math.floor(Math.random() * 5 + 1)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
