import { useState } from 'react';
import { Plus, Send, Calendar as CalendarIcon, Facebook, Linkedin, Users } from 'lucide-react';

interface Announcement {
  id: number;
  title: string;
  content: string;
  author: string;
  date: string;
  category: 'internal' | 'external';
  platforms?: string[];
  status: 'published' | 'scheduled' | 'draft';
  scheduledDate?: string;
}

const mockAnnouncements: Announcement[] = [
  {
    id: 1,
    title: 'Nouvelle politique de télétravail',
    content: 'À partir du 1er avril, nous mettons en place une nouvelle politique de télétravail flexible...',
    author: 'Direction RH',
    date: '2026-03-20',
    category: 'internal',
    status: 'published',
  },
  {
    id: 2,
    title: 'Recrutement: Développeur Senior',
    content: 'Nous recherchons un développeur senior pour rejoindre notre équipe IT...',
    author: 'Marie Dubois',
    date: '2026-03-18',
    category: 'external',
    platforms: ['LinkedIn', 'Facebook'],
    status: 'published',
  },
  {
    id: 3,
    title: 'Team Building - Save the Date',
    content: 'Réservez votre journée du 15 mai pour notre team building annuel!',
    author: 'Comité d\'entreprise',
    date: '2026-03-15',
    category: 'internal',
    status: 'scheduled',
    scheduledDate: '2026-04-01',
  },
  {
    id: 4,
    title: 'Ouverture nouveau bureau Paris',
    content: 'Nous sommes ravis d\'annoncer l\'ouverture de notre nouveau bureau à Paris...',
    author: 'Direction',
    date: '2026-03-22',
    category: 'external',
    platforms: ['LinkedIn'],
    status: 'published',
  },
];

export function Communication() {
  const [showModal, setShowModal] = useState(false);
  const [filterCategory, setFilterCategory] = useState<'all' | 'internal' | 'external'>('all');

  const filteredAnnouncements = filterCategory === 'all'
    ? mockAnnouncements
    : mockAnnouncements.filter(a => a.category === filterCategory);

  const getStatusBadge = (status: Announcement['status']) => {
    const statusConfig = {
      published: { label: 'Publié', class: 'bg-green-100 text-green-700' },
      scheduled: { label: 'Planifié', class: 'bg-orange-100 text-orange-700' },
      draft: { label: 'Brouillon', class: 'bg-gray-100 text-gray-700' },
    };
    const config = statusConfig[status];
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${config.class}`}>
        {config.label}
      </span>
    );
  };

  const getCategoryBadge = (category: Announcement['category']) => {
    return (
      <span
        className={`px-3 py-1 rounded-full text-xs font-medium ${
          category === 'internal'
            ? 'bg-blue-100 text-blue-700'
            : 'bg-purple-100 text-purple-700'
        }`}
      >
        {category === 'internal' ? 'Interne' : 'Externe'}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Communication & Annonces</h2>
          <p className="text-gray-600 mt-1">Gérez les annonces internes et publications externes</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Nouvelle annonce
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-gray-800">{mockAnnouncements.length}</div>
            <Send className="text-blue-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Total annonces</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-blue-600">
              {mockAnnouncements.filter(a => a.category === 'internal').length}
            </div>
            <Users className="text-blue-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Internes</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-purple-600">
              {mockAnnouncements.filter(a => a.category === 'external').length}
            </div>
            <Linkedin className="text-purple-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Externes</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-orange-600">
              {mockAnnouncements.filter(a => a.status === 'scheduled').length}
            </div>
            <CalendarIcon className="text-orange-600" size={24} />
          </div>
          <div className="text-sm text-gray-600">Planifiées</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <div className="flex gap-2">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterCategory === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Toutes
          </button>
          <button
            onClick={() => setFilterCategory('internal')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterCategory === 'internal'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Internes
          </button>
          <button
            onClick={() => setFilterCategory('external')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterCategory === 'external'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Externes
          </button>
        </div>
      </div>

      {/* Announcements Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredAnnouncements.map((announcement) => (
          <div
            key={announcement.id}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex gap-2">
                {getCategoryBadge(announcement.category)}
                {getStatusBadge(announcement.status)}
              </div>
            </div>

            <h3 className="text-lg font-bold text-gray-800 mb-2">{announcement.title}</h3>
            <p className="text-gray-600 mb-4 line-clamp-3">{announcement.content}</p>

            {announcement.platforms && announcement.platforms.length > 0 && (
              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm text-gray-600">Publié sur:</span>
                {announcement.platforms.map((platform) => (
                  <span
                    key={platform}
                    className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 rounded text-xs"
                  >
                    {platform === 'LinkedIn' && <Linkedin size={14} className="text-blue-700" />}
                    {platform === 'Facebook' && <Facebook size={14} className="text-blue-600" />}
                    {platform}
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
              <span>Par {announcement.author}</span>
              <span>{announcement.date}</span>
            </div>

            {announcement.status === 'scheduled' && announcement.scheduledDate && (
              <div className="flex items-center gap-2 p-3 bg-orange-50 rounded-lg mb-4">
                <CalendarIcon size={16} className="text-orange-600" />
                <span className="text-sm text-orange-700">
                  Planifié pour le {announcement.scheduledDate}
                </span>
              </div>
            )}

            <div className="flex gap-2">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                Modifier
              </button>
              <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                Voir détails
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* New Announcement Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-800">Créer une nouvelle annonce</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titre de l'annonce
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Titre accrocheur..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type d'annonce
                </label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Interne - Employés uniquement</option>
                  <option>Externe - Publication réseaux sociaux</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Contenu
                </label>
                <textarea
                  rows={6}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Rédigez votre annonce..."
                ></textarea>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Plateformes de publication (pour annonces externes)
                </label>
                <div className="space-y-2">
                  <label className="flex items-center gap-3">
                    <input type="checkbox" className="w-5 h-5 text-blue-600" />
                    <Linkedin size={20} className="text-blue-700" />
                    <span className="text-sm text-gray-700">LinkedIn</span>
                  </label>
                  <label className="flex items-center gap-3">
                    <input type="checkbox" className="w-5 h-5 text-blue-600" />
                    <Facebook size={20} className="text-blue-600" />
                    <span className="text-sm text-gray-700">Facebook</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Planification (optionnel)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="date"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="time"
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Annuler
                </button>
                <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  Enregistrer brouillon
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Publier
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
