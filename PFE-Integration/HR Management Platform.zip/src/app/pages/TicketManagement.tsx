import { useState } from 'react';
import { Plus, Search, AlertCircle, Clock, CheckCircle, MessageSquare } from 'lucide-react';

interface Ticket {
  id: number;
  title: string;
  description: string;
  employeeName: string;
  category: string;
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  createdDate: string;
  updatedDate: string;
  slaDeadline: string;
}

const mockTickets: Ticket[] = [
  { id: 1, title: 'Problème de connexion VPN', description: 'Impossible de se connecter au VPN depuis ce matin', employeeName: 'Marie Dubois', category: 'IT', priority: 'URGENT', status: 'in-progress', createdDate: '2026-03-23 09:15', updatedDate: '2026-03-23 10:30', slaDeadline: '2026-03-23 17:00' },
  { id: 2, title: 'Demande de matériel', description: 'Besoin d\'un écran supplémentaire', employeeName: 'Jean Martin', category: 'Matériel', priority: 'NORMAL', status: 'open', createdDate: '2026-03-22 14:20', updatedDate: '2026-03-22 14:20', slaDeadline: '2026-03-25 14:20' },
  { id: 3, title: 'Erreur application RH', description: 'L\'application affiche une erreur lors de la soumission', employeeName: 'Sophie Bernard', category: 'RH', priority: 'HIGH', status: 'in-progress', createdDate: '2026-03-22 11:00', updatedDate: '2026-03-23 08:45', slaDeadline: '2026-03-24 11:00' },
  { id: 4, title: 'Question sur fiche de paie', description: 'Clarification nécessaire sur la dernière fiche de paie', employeeName: 'Luc Petit', category: 'Finance', priority: 'LOW', status: 'resolved', createdDate: '2026-03-20 16:30', updatedDate: '2026-03-22 09:00', slaDeadline: '2026-03-27 16:30' },
  { id: 5, title: 'Accès parking', description: 'Badge de parking ne fonctionne plus', employeeName: 'Claire Moreau', category: 'Logistique', priority: 'NORMAL', status: 'open', createdDate: '2026-03-23 08:00', updatedDate: '2026-03-23 08:00', slaDeadline: '2026-03-26 08:00' },
];

export function TicketManagement() {
  const [showModal, setShowModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [filterPriority, setFilterPriority] = useState<'all' | Ticket['priority']>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | Ticket['status']>('all');

  const filteredTickets = mockTickets.filter(ticket => {
    if (filterPriority !== 'all' && ticket.priority !== filterPriority) return false;
    if (filterStatus !== 'all' && ticket.status !== filterStatus) return false;
    return true;
  });

  const getPriorityBadge = (priority: Ticket['priority']) => {
    const priorityConfig = {
      LOW: { label: 'Faible', class: 'bg-gray-100 text-gray-700' },
      NORMAL: { label: 'Normal', class: 'bg-blue-100 text-blue-700' },
      HIGH: { label: 'Élevé', class: 'bg-orange-100 text-orange-700' },
      URGENT: { label: 'Urgent', class: 'bg-red-100 text-red-700' },
    };
    const config = priorityConfig[priority];
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${config.class}`}>
        {config.label}
      </span>
    );
  };

  const getStatusBadge = (status: Ticket['status']) => {
    const statusConfig = {
      'open': { label: 'Ouvert', class: 'bg-blue-100 text-blue-700' },
      'in-progress': { label: 'En cours', class: 'bg-orange-100 text-orange-700' },
      'resolved': { label: 'Résolu', class: 'bg-green-100 text-green-700' },
      'closed': { label: 'Fermé', class: 'bg-gray-100 text-gray-700' },
    };
    const config = statusConfig[status];
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${config.class}`}>
        {config.label}
      </span>
    );
  };

  const stats = {
    total: mockTickets.length,
    open: mockTickets.filter(t => t.status === 'open').length,
    inProgress: mockTickets.filter(t => t.status === 'in-progress').length,
    resolved: mockTickets.filter(t => t.status === 'resolved').length,
    urgent: mockTickets.filter(t => t.priority === 'URGENT').length,
  };

  const isNearSLA = (deadline: string) => {
    const now = new Date('2026-03-23 12:00'); // Current time for demo
    const sla = new Date(deadline);
    const hoursRemaining = (sla.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursRemaining < 8 && hoursRemaining > 0;
  };

  const isOverSLA = (deadline: string) => {
    const now = new Date('2026-03-23 12:00');
    const sla = new Date(deadline);
    return now > sla;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Gestion des Tickets</h2>
          <p className="text-gray-600 mt-1">Support et suivi des demandes</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Créer un ticket
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-gray-800 mb-2">{stats.total}</div>
          <div className="text-sm text-gray-600">Total tickets</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-blue-600 mb-2">{stats.open}</div>
          <div className="text-sm text-gray-600">Ouverts</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-orange-600 mb-2">{stats.inProgress}</div>
          <div className="text-sm text-gray-600">En cours</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="text-3xl font-bold text-green-600 mb-2">{stats.resolved}</div>
          <div className="text-sm text-gray-600">Résolus</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-red-100 border-2">
          <div className="text-3xl font-bold text-red-600 mb-2">{stats.urgent}</div>
          <div className="text-sm text-gray-600">Urgents</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Rechercher un ticket..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select 
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value as any)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">Toutes priorités</option>
            <option value="LOW">Faible</option>
            <option value="NORMAL">Normal</option>
            <option value="HIGH">Élevé</option>
            <option value="URGENT">Urgent</option>
          </select>
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">Tous statuts</option>
            <option value="open">Ouvert</option>
            <option value="in-progress">En cours</option>
            <option value="resolved">Résolu</option>
            <option value="closed">Fermé</option>
          </select>
        </div>
      </div>

      {/* Tickets Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Ticket
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Employé
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Catégorie
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Priorité
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  SLA
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <div className="font-medium text-gray-900">#{ticket.id} - {ticket.title}</div>
                      <div className="text-sm text-gray-500 mt-1 truncate max-w-xs">{ticket.description}</div>
                      <div className="text-xs text-gray-400 mt-1">Créé: {ticket.createdDate}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm">
                        {ticket.employeeName.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="ml-3">
                        <div className="text-sm font-medium text-gray-900">{ticket.employeeName}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {ticket.category}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getPriorityBadge(ticket.priority)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(ticket.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {ticket.status !== 'resolved' && ticket.status !== 'closed' && (
                      <div className="flex items-center gap-2">
                        {isOverSLA(ticket.slaDeadline) ? (
                          <span className="flex items-center gap-1 text-sm text-red-600 font-medium">
                            <AlertCircle size={16} />
                            Dépassé
                          </span>
                        ) : isNearSLA(ticket.slaDeadline) ? (
                          <span className="flex items-center gap-1 text-sm text-orange-600 font-medium">
                            <Clock size={16} />
                            Bientôt
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-sm text-green-600 font-medium">
                            <CheckCircle size={16} />
                            OK
                          </span>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <button 
                      onClick={() => setSelectedTicket(ticket)}
                      className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Voir détails
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Ticket Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-800">Créer un nouveau ticket</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titre du ticket
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Résumé du problème..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Catégorie
                  </label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>IT</option>
                    <option>RH</option>
                    <option>Finance</option>
                    <option>Matériel</option>
                    <option>Logistique</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Priorité
                  </label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>LOW - Faible</option>
                    <option>NORMAL - Normal</option>
                    <option>HIGH - Élevé</option>
                    <option>URGENT - Urgent</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description détaillée
                </label>
                <textarea
                  rows={6}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Décrivez le problème en détail..."
                ></textarea>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Annuler
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Créer le ticket
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ticket Detail Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-gray-800">Ticket #{selectedTicket.id}</h3>
                {getPriorityBadge(selectedTicket.priority)}
                {getStatusBadge(selectedTicket.status)}
              </div>
              <button
                onClick={() => setSelectedTicket(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="text-lg font-bold text-gray-800 mb-2">{selectedTicket.title}</h4>
                <p className="text-gray-600">{selectedTicket.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Employé</div>
                  <div className="font-medium text-gray-800">{selectedTicket.employeeName}</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Catégorie</div>
                  <div className="font-medium text-gray-800">{selectedTicket.category}</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Créé le</div>
                  <div className="font-medium text-gray-800">{selectedTicket.createdDate}</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Dernière mise à jour</div>
                  <div className="font-medium text-gray-800">{selectedTicket.updatedDate}</div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Échéance SLA</div>
                  <div className="font-medium text-blue-600">{selectedTicket.slaDeadline}</div>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex items-center gap-2 mb-4">
                  <MessageSquare size={20} className="text-gray-600" />
                  <h5 className="font-semibold text-gray-800">Historique & Commentaires</h5>
                </div>
                <div className="space-y-3">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-800">Admin Support</span>
                      <span className="text-sm text-gray-500">{selectedTicket.updatedDate}</span>
                    </div>
                    <p className="text-gray-600">Ticket pris en charge. Investigation en cours...</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Marquer comme résolu
                </button>
                <button className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                  Changer priorité
                </button>
                <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  Ajouter un commentaire
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
