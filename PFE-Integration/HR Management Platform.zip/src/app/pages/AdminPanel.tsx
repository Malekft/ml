import { Shield, Users, Settings, Key, Bell, Database, Lock, Activity, AlertCircle, CheckCircle } from 'lucide-react';

const users = [
  { id: 1, nom: 'Marie Dubois', email: 'marie.dubois@company.com', role: 'Manager', statut: 'Actif', dernierAcces: '23/03/2026 14:32' },
  { id: 2, nom: 'Jean Martin', email: 'jean.martin@company.com', role: 'Employé', statut: 'Actif', dernierAcces: '23/03/2026 14:15' },
  { id: 3, nom: 'Sophie Bernard', email: 'sophie.bernard@company.com', role: 'Manager', statut: 'Actif', dernierAcces: '23/03/2026 13:45' },
  { id: 4, nom: 'Luc Petit', email: 'luc.petit@company.com', role: 'Employé', statut: 'Actif', dernierAcces: '23/03/2026 12:20' },
  { id: 5, nom: 'Emma Rousseau', email: 'emma.rousseau@company.com', role: 'Manager', statut: 'Inactif', dernierAcces: '20/03/2026 09:12' },
];

const roles = [
  {
    nom: 'Manager',
    permissions: ['Gestion complète', 'Configuration système', 'Gestion utilisateurs', 'Analytics avancés', 'Validation congés', 'Gestion tickets', 'Rapports'],
    utilisateurs: 23,
    couleur: 'blue'
  },
  {
    nom: 'Employé',
    permissions: ['Demandes congés', 'Création tickets', 'Profil personnel', 'Messages internes'],
    utilisateurs: 225,
    couleur: 'green'
  },
];

const systemSettings = [
  {
    categorie: 'Sécurité',
    parametres: [
      { nom: 'Authentification JWT', valeur: 'Activée', statut: 'actif' },
      { nom: 'Session timeout', valeur: '30 minutes', statut: 'actif' },
      { nom: 'Mot de passe fort', valeur: 'Requis', statut: 'actif' },
      { nom: 'Authentification 2FA', valeur: 'Optionnelle', statut: 'warning' },
    ]
  },
  {
    categorie: 'Notifications',
    parametres: [
      { nom: 'Email automatiques', valeur: 'Activé', statut: 'actif' },
      { nom: 'Rappels SLA', valeur: '48 heures', statut: 'actif' },
      { nom: 'Notifications push', valeur: 'Activé', statut: 'actif' },
      { nom: 'Digest hebdomadaire', valeur: 'Lundi 9h', statut: 'actif' },
    ]
  },
  {
    categorie: 'Intégrations',
    parametres: [
      { nom: 'n8n Automation', valeur: 'Connecté', statut: 'actif' },
      { nom: 'API externe', valeur: 'YOUR_API_KEY_HERE', statut: 'warning' },
      { nom: 'Webhooks', valeur: 'Activé', statut: 'actif' },
      { nom: 'Sync LDAP', valeur: 'Désactivé', statut: 'inactive' },
    ]
  },
];

const activityLogs = [
  { id: 1, utilisateur: 'Marie Dubois', action: 'Modification des permissions (Manager)', timestamp: '23/03/2026 14:25', type: 'security' },
  { id: 2, utilisateur: 'Admin Système', action: 'Mise à jour de la configuration JWT', timestamp: '23/03/2026 10:15', type: 'system' },
  { id: 3, utilisateur: 'Jean Martin', action: 'Tentative de connexion échouée (3x)', timestamp: '22/03/2026 18:45', type: 'warning' },
  { id: 4, utilisateur: 'Sophie Bernard', action: 'Export des données Analytics', timestamp: '22/03/2026 16:30', type: 'info' },
  { id: 5, utilisateur: 'Admin Système', action: 'Sauvegarde base de données effectuée', timestamp: '22/03/2026 02:00', type: 'success' },
];

export function AdminPanel() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Panneau d'Administration</h2>
          <p className="text-gray-600 mt-1">Gestion des utilisateurs, rôles et configuration système</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-red-50 border border-red-200 rounded-lg">
          <Shield className="text-red-600" size={20} />
          <span className="text-sm font-medium text-red-700">Accès Administrateur</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Utilisateurs Actifs</div>
            <Users className="text-blue-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">248</div>
          <div className="text-xs text-gray-500">+12 ce mois</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Rôles Configurés</div>
            <Shield className="text-green-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">2</div>
          <div className="text-xs text-gray-500">Manager, Employé</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Sécurité</div>
            <Lock className="text-red-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">98%</div>
          <div className="text-xs text-gray-500">Score de sécurité</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-gray-600">Uptime</div>
            <Activity className="text-purple-600" size={20} />
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-1">99.9%</div>
          <div className="text-xs text-gray-500">30 derniers jours</div>
        </div>
      </div>

      {/* Roles Management */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Shield className="text-blue-600" size={24} />
            <h3 className="text-lg font-semibold text-gray-800">Gestion des Rôles & Permissions</h3>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
            Créer un Rôle
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {roles.map((role) => (
            <div key={role.nom} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <h4 className={`text-lg font-semibold text-${role.couleur}-600`}>{role.nom}</h4>
                <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                  {role.utilisateurs} utilisateurs
                </span>
              </div>
              <div className="space-y-2">
                {role.permissions.map((permission, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                    <CheckCircle className="text-green-600" size={16} />
                    <span>{permission}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
                <button className="flex-1 px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                  Modifier
                </button>
                <button className="flex-1 px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                  Voir plus
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Users className="text-blue-600" size={24} />
            <h3 className="text-lg font-semibold text-gray-800">Gestion des Utilisateurs</h3>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
            Ajouter Utilisateur
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Utilisateur</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Rôle</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Statut</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Dernier Accès</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{user.nom}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{user.email}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      user.role === 'Manager' ? 'bg-blue-100 text-blue-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      user.statut === 'Actif' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {user.statut}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">{user.dernierAcces}</td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex gap-2">
                      <button className="text-blue-600 hover:underline">Éditer</button>
                      <button className="text-red-600 hover:underline">Supprimer</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* System Settings */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-6">
          <Settings className="text-blue-600" size={24} />
          <h3 className="text-lg font-semibold text-gray-800">Configuration Système</h3>
        </div>
        <div className="space-y-6">
          {systemSettings.map((section) => (
            <div key={section.categorie}>
              <h4 className="text-md font-semibold text-gray-700 mb-3 flex items-center gap-2">
                {section.categorie === 'Sécurité' && <Lock className="text-red-600" size={20} />}
                {section.categorie === 'Notifications' && <Bell className="text-orange-600" size={20} />}
                {section.categorie === 'Intégrations' && <Database className="text-blue-600" size={20} />}
                {section.categorie}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {section.parametres.map((param, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center gap-2">
                      {param.statut === 'actif' && <CheckCircle className="text-green-600" size={16} />}
                      {param.statut === 'warning' && <AlertCircle className="text-orange-600" size={16} />}
                      {param.statut === 'inactive' && <AlertCircle className="text-gray-400" size={16} />}
                      <div>
                        <div className="text-sm font-medium text-gray-900">{param.nom}</div>
                        <div className="text-xs text-gray-500">{param.valeur}</div>
                      </div>
                    </div>
                    <button className="text-sm text-blue-600 hover:underline">Modifier</button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activity Logs */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="text-blue-600" size={24} />
          <h3 className="text-lg font-semibold text-gray-800">Journal d'Activité Système</h3>
        </div>
        <div className="space-y-3">
          {activityLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
              <div className={`w-2 h-2 rounded-full mt-2 ${
                log.type === 'security' ? 'bg-red-500' :
                log.type === 'warning' ? 'bg-orange-500' :
                log.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
              }`}></div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">{log.utilisateur}</span>
                  <span className="text-xs text-gray-500">{log.timestamp}</span>
                </div>
                <p className="text-sm text-gray-700 mt-1">{log.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* API Configuration */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
            <Key className="text-white" size={24} />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Configuration API & Intégrations</h3>
            <p className="text-sm text-gray-700 mb-3">
              Pour intégrer des services externes, veuillez configurer vos clés API.
              Les clés sont stockées de manière sécurisée et chiffrées dans la base de données.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-gray-200">
                <div className="text-xs text-gray-600 mb-1">API Key (Placeholder)</div>
                <code className="text-sm font-mono text-gray-800">YOUR_API_KEY_HERE</code>
              </div>
              <div className="bg-white rounded-lg p-3 border border-gray-200">
                <div className="text-xs text-gray-600 mb-1">JWT Secret</div>
                <code className="text-sm font-mono text-gray-800">••••••••••••••••</code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
