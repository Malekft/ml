import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/layouts/RootLayout";
import { Dashboard } from "./pages/Dashboard";
import { Login } from "./pages/Login";
import { EmployeeManagement } from "./pages/EmployeeManagement";
import { LeaveManagement } from "./pages/LeaveManagement";
import { TicketManagement } from "./pages/TicketManagement";
import { WorkflowAutomation } from "./pages/WorkflowAutomation";
import { Communication } from "./pages/Communication";
import { BIDashboard } from "./pages/BIDashboard";
import { PredictiveAnalytics } from "./pages/PredictiveAnalytics";
import { AdminPanel } from "./pages/AdminPanel";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "employees", Component: EmployeeManagement },
      { path: "leaves", Component: LeaveManagement },
      { path: "tickets", Component: TicketManagement },
      { path: "workflows", Component: WorkflowAutomation },
      { path: "communication", Component: Communication },
      { path: "bi-dashboard", Component: BIDashboard },
      { path: "analytics", Component: PredictiveAnalytics },
      { path: "admin", Component: AdminPanel },
    ],
  },
]);
