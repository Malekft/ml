
  # HR Management Platform

  This is a code bundle for HR Management Platform. The original project is available at https://www.figma.com/design/s5BwML2vP2DxqE38UYLjbX/HR-Management-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  